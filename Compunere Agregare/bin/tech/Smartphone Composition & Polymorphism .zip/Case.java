package tech;

public class Case{

	public void pressPowerButton() {
		System.out.println("class Case: Power button pressed.");
	}
 
	public void pressVolumeUp() {
		System.out.println("class Case: Volume UP pressed.");
	}
 
	public void pressVolumeDown() {
		System.out.println("class Case: Volume DOWN pressed.");
	}
}	