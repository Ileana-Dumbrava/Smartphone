package tech;

public class Dimensions {

	private final int width;
	private final int length;
	private final int depth;
	
	public Dimensions(int width, int length, int depth) {
		this.width = width;
		this.length = length;
		this.depth = depth;
	}
	
}
